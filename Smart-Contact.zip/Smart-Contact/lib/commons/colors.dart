import 'package:flutter/material.dart';

class ColorApp {
  static const Color main_color = Colors.teal;
}
